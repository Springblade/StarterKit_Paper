import { toNextJsHandler } from 'better-auth/next-js';
import { auth } from '@/services/auth/index';

export const { GET, POST } = toNextJsHandler(auth);
